function mostrarMensagem() {
  document.getElementById("mensagem").innerText = "Você é capaz de conquistar tudo o que quiser. Nunca desista!";
}
